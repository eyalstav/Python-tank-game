<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="all_tiles" tilewidth="32" tileheight="32" spacing="5" tilecount="40" columns="10">
 <image source="all_tiles.png" width="401" height="143"/>
</tileset>
